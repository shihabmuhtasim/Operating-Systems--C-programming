gcc -o as5 as5.c -lm
./as5